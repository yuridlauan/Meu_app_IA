# -*- coding: utf-8 -*-
# /paginas/categorias.py

import streamlit as st
import pandas as pd
from funcoes_compartilhadas import conversa_banco, trata_tabelas
from funcoes_compartilhadas.estilos import set_page_title

# ─── Configurações da Tabela ───────────────────────────────────────
TABELA = "categorias"
TIPOS_COLUNAS = {
    "Nome": "texto",
    "Tipo": "texto",  # Receita ou Despesa
    "ID": "id",
}

# ─── Função Principal ──────────────────────────────────────────────
def app():
    set_page_title("Gerenciar Categorias")
    trata_tabelas.gerenciar_estado_grid("categorias")

    # ─── Leitura dos Dados ─────────────────────────────────────────
    df = conversa_banco.select(TABELA, TIPOS_COLUNAS)

    # ─── Linha com botões Criar + Filtro ───────────────────────────
    col1, col2 = st.columns([1, 8])

    with col1:
        with st.popover("➕ Criar"):
            st.subheader("Adicionar Nova Categoria")
            nome = st.text_input("Nome da Categoria")
            tipo = st.selectbox("Tipo", ["Receita", "Despesa"])

            if st.button("💾 Salvar Categoria"):
                if not nome:
                    st.warning("⚠️ Informe o nome da categoria.")
                else:
                    nova = {"Nome": nome, "Tipo": tipo}
                    conversa_banco.insert(TABELA, nova)
                    st.success("✅ Categoria salva com sucesso!")
                    st.cache_data.clear()
                    st.rerun()

    with col2:
        df_vis = trata_tabelas.filtrar_tabela(df, ["Nome", "Tipo"], nome="categorias")

    # ─── Grid com os Dados ─────────────────────────────────────────
    st.subheader("Categorias Cadastradas")
    visiveis = {"Nome": "Nome da Categoria", "Tipo": "Tipo (Receita ou Despesa)"}
    edit, ids = trata_tabelas.grid(df_vis, visiveis, id_col="ID")

    # ─── Salvar Edições ────────────────────────────────────────────
    trata_tabelas.salvar_edicoes(
        edit, df,
        ["Nome", "Tipo"],
        conversa_banco.update,
        TABELA, "ID", TIPOS_COLUNAS,
    )

    # ─── Opções (Deletar e Clonar) ─────────────────────────────────
    trata_tabelas.opcoes_especiais(
        TABELA, ids,
        conversa_banco.delete,
        "ID", TIPOS_COLUNAS,
        fn_insert=conversa_banco.insert,
    )

# -*- coding: utf-8 -*-
import streamlit as st
from funcoes_compartilhadas.estilos import set_page_title

# ──────────────────────────────────────────────────────────────────────────────
# ⚙️ Parâmetros fixos da norma
VALOR_BASE = 150.35
LIMITE_AREA = 100
VALOR_EXCEDENTE = 0.22

# ──────────────────────────────────────────────────────────────────────────────
# 🧮 Função que calcula o valor da vistoria
def calcular_vistoria(area: float) -> float:
    if area <= LIMITE_AREA:
        return VALOR_BASE
    excedente = area - LIMITE_AREA
    return round(VALOR_BASE + excedente * VALOR_EXCEDENTE, 2)

# ──────────────────────────────────────────────────────────────────────────────
# 🖥️ Interface Streamlit
def app():
    set_page_title("Cálculo de Vistoria")

    st.subheader("Informe os dados abaixo")

    area = st.number_input("Área construída (m²)", min_value=0.0, format="%.2f")

    if st.button("Calcular Taxa de Vistoria"):
        valor = calcular_vistoria(area)
        st.success(f"💰 Valor da vistoria: **R$ {valor:.2f}**")

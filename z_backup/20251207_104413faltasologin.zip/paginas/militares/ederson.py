from paginas.militares.modelo_militar import app as modelo

def app():
    modelo("2° Sgt Éderson")

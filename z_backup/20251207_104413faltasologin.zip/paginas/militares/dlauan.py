from paginas.militares.modelo_militar import app as modelo

def app():
    modelo("Asp Of D'Lauan")


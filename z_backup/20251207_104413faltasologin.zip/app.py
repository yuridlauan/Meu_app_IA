import streamlit as st

st.title("🚀 Meu App com I.A.")
st.write("Parabéns, seu ambiente está rodando com Streamlit!")

from paginas.protocolos import app as app_protocolos

def app():
    app_protocolos("Estrela do Norte")

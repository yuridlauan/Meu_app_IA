# -*- coding: utf-8 -*-
import streamlit as st
from funcoes_compartilhadas import conversa_banco, trata_tabelas
from funcoes_compartilhadas.estilos import set_page_title

# ─── CONFIGURAÇÕES DA PLANILHA ─────────────────────────────────────
TABELA = "Página1"   # Nome da aba no Google Sheets

TIPOS_COLUNAS = {
    "Nome": "texto",
    "Peso": "numero100",        # será armazenado multiplicado por 100
    "Altura": "numero100",      # idem
    "IMC": "numero100",
    "Classificação": "texto",
    "ID": "id",
}

# ─── FUNÇÃO AUXILIAR ──────────────────────────────────────────────
def calcula_imc(peso: float, altura: float) -> tuple[float, str]:
    """Calcula o IMC e retorna a classificação"""
    if peso <= 0 or altura <= 0:
        return 0, "Dados Inválidos"
    imc = peso / (altura ** 2)
    cls = (
        "Abaixo do peso" if imc < 18.5 else
        "Peso normal"    if imc < 24.9 else
        "Sobrepeso"      if imc < 29.9 else
        "Obesidade I"    if imc < 34.9 else
        "Obesidade II"   if imc < 39.9 else
        "Obesidade III"
    )
    return round(imc, 2), cls

# ─── FORMULÁRIO NOVO REGISTRO ─────────────────────────────────────
def formulario_novo_registro(container, key_suffix=""):
    with container:
        st.subheader("Novo Registro")
        nome   = st.text_input("Nome (opcional)", key=f"nome{key_suffix}")
        peso   = st.number_input("Peso (kg)",   0.0, format="%.2f", step=0.1, key=f"peso{key_suffix}")
        altura = st.number_input("Altura (m)",  0.0, format="%.2f", step=0.01, key=f"altura{key_suffix}")

        if st.button("Calcular e Salvar", key=f"salvar{key_suffix}"):
            imc, cls = calcula_imc(peso, altura)
            if imc > 0:
                st.success(f"IMC = {imc:.2f} ({cls})")
                registro = {
                    "Nome": nome,
                    "Peso": round(peso, 2),
                    "Altura": round(altura, 2),
                    "IMC": imc,
                    "Classificação": cls,
                }
                conversa_banco.insert(TABELA, registro)
                st.cache_data.clear()
                st.rerun()
            else:
                st.error("Informe peso e altura válidos.")

# ─── PROGRAMA PRINCIPAL ───────────────────────────────────────────
def app():
    set_page_title("Calculadora de IMC")
    trata_tabelas.gerenciar_estado_grid("imc")

    # Coluna lateral: formulário de criação
    col1, col2 = st.columns([1, 9])
    with col1:
        with st.popover("➕ Criar"):
            formulario_novo_registro(st.container(), key_suffix="_lateral")

    # Lê dados da planilha
    df = conversa_banco.select(TABELA, TIPOS_COLUNAS)
    if df.empty:
        st.warning("Nenhum registro.")
        return

    # Coluna principal: filtros e tabela
    with col2:
        df_vis = trata_tabelas.filtrar_tabela(df, ["Nome", "Classificação"], nome="imc")

    st.subheader("Histórico de IMC")
    visiveis = {c: c for c in ["Nome", "Peso", "Altura", "IMC", "Classificação"]}

    edit, ids = trata_tabelas.grid(df_vis, visiveis, id_col="ID")

    # Salvar alterações no banco
    trata_tabelas.salvar_edicoes(
        edit, df,
        ["Nome", "Peso", "Altura", "IMC", "Classificação"],
        conversa_banco.update,
        TABELA, "ID", TIPOS_COLUNAS,
    )

    # Opções: deletar ou clonar registros
    trata_tabelas.opcoes_especiais(
        TABELA, ids,
        conversa_banco.delete,
        "ID", TIPOS_COLUNAS,
        fn_insert=conversa_banco.insert,
    )


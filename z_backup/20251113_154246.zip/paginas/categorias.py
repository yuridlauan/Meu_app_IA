# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
from datetime import date, timedelta, datetime
import math
from funcoes_compartilhadas.conversa_banco import select, insert, update, delete
from funcoes_compartilhadas.cria_id import cria_id

# ───────────────────────────────────────────────────────────────────────────────
# CONFIGURAÇÕES BÁSICAS
# ───────────────────────────────────────────────────────────────────────────────
TABELA = "Protocolos"

TIPOS_COLUNAS = {
    "ID": "id",
    "Data de Protocolo": "data",
    "Nº de Protocolo": "texto",
    "Tipo de Serviço": "texto",
    "CPF/CNPJ": "texto",
    "Nome Fantasia": "texto",
    "Área (m²)": "numero",
    "Valor Total": "numero100",
    "Validade do Boleto": "data",
    "Validade do Cercon": "data",
    "Prazo de Vistoria": "data",
    "Contato": "texto",
    "Militar Responsável": "texto",
    "Andamento": "texto"
}

# ───────────────────────────────────────────────────────────────────────────────
# FUNÇÕES AUXILIARES
# ───────────────────────────────────────────────────────────────────────────────
def sanitize_number(value, default=0.0):
    try:
        if isinstance(value, str):
            value = value.replace(",", ".").strip()
        value = float(value)
        if math.isnan(value):
            return default
        return value
    except (ValueError, TypeError):
        return default


def calcular_vistoria(area: float) -> float:
    VALOR_BASE = 150.35
    LIMITE_AREA = 100
    VALOR_EXCEDENTE = 0.22
    if area <= LIMITE_AREA:
        return VALOR_BASE
    excedente = area - LIMITE_AREA
    return round(VALOR_BASE + excedente * VALOR_EXCEDENTE, 2)


def carregar_dados():
    df = select(TABELA, TIPOS_COLUNAS)
    df = pd.DataFrame(df)

    # Converte automaticamente qualquer valor numérico de data
    def corrige_data(valor):
        try:
            if pd.isna(valor) or str(valor).strip() == "":
                return ""
            if str(valor).isdigit():
                # Trata o formato numérico (ex: 45973)
                data = pd.to_datetime("1899-12-30") + pd.to_timedelta(int(valor), unit="D")
                return data.strftime("%d/%m/%Y")
            else:
                data = pd.to_datetime(str(valor), dayfirst=True, errors="coerce")
                if pd.notna(data):
                    return data.strftime("%d/%m/%Y")
                return str(valor)
        except Exception:
            return str(valor)

    for coluna in ["Data de Protocolo", "Validade do Boleto", "Validade do Cercon", "Prazo de Vistoria"]:
        if coluna in df.columns:
            df[coluna] = df[coluna].apply(corrige_data)

    return df


def classificar_vencimentos(df_base: pd.DataFrame):
    df_aux = df_base.copy()
    df_aux["Validade do Cercon_dt"] = pd.to_datetime(
        df_aux["Validade do Cercon"], dayfirst=True, errors="coerce"
    )
    hoje = pd.Timestamp.today().normalize()
    limite = hoje + pd.Timedelta(days=30)
    proximos = df_aux[
        (df_aux["Validade do Cercon_dt"] >= hoje) &
        (df_aux["Validade do Cercon_dt"] <= limite)
    ]
    vencidos = df_aux[df_aux["Validade do Cercon_dt"] < hoje]
    return proximos, vencidos


# ───────────────────────────────────────────────────────────────────────────────
# FORMULÁRIO PADRÃO USADO EM CADASTRO E EDIÇÃO
# ───────────────────────────────────────────────────────────────────────────────
def formulario_protocolo(dados=None, prefix=""):
    if dados is None:
        data_protocolo_padrao = date.today()
        dados = {
            "Data de Protocolo": data_protocolo_padrao.strftime("%d/%m/%Y"),
            "Nº de Protocolo": "",
            "Tipo de Serviço": "",
            "CPF/CNPJ": "",
            "Nome Fantasia": "",
            "Área (m²)": 0.0,
            "Valor Total": 0.0,
            "Validade do Boleto": "",
            "Validade do Cercon": "",
            "Prazo de Vistoria": "",
            "Contato": "",
            "Militar Responsável": "",
            "Andamento": ""
        }

    col1, col2 = st.columns(2)

    with col1:
        data_raw = st.text_input("Data de Protocolo (dd/mm/aaaa)",
                                 value=dados["Data de Protocolo"], key=f"data_{prefix}")

        try:
            data_convertida = datetime.strptime(data_raw, "%d/%m/%Y").date()
        except ValueError:
            data_convertida = date.today()

        protocolo = st.text_input("Nº de Protocolo",
                                  value=dados["Nº de Protocolo"], key=f"prot_{prefix}")
        tipo = st.selectbox("Tipo de Serviço",
                            ["Vistoria para Funcionamento", "Licenciamento Facilitado",
                             "Análise de Projeto", "Substituição de Projeto"],
                            index=0, key=f"tipo_{prefix}")
        cpf = st.text_input("CPF/CNPJ", value=dados["CPF/CNPJ"], key=f"cpf_{prefix}")
        nome = st.text_input("Nome Fantasia", value=dados["Nome Fantasia"], key=f"nome_{prefix}")

        area = st.number_input("Área (m²)", min_value=0.0, format="%.2f",
                               value=float(dados.get("Área (m²)", 0.0)), key=f"area_{prefix}")

        valor_calculado = calcular_vistoria(area)
        valor = st.number_input("Valor Total (R$)", min_value=0.0, format="%.2f",
                                value=valor_calculado if prefix == "novo" else float(dados.get("Valor Total", 0.0)),
                                key=f"valor_{prefix}")
        st.caption(f"💡 Valor calculado automaticamente: R$ {valor_calculado:.2f}")

    with col2:
        validade_boleto = st.text_input("Validade do Boleto (dd/mm/aaaa)",
                                        value=(data_convertida + timedelta(days=30)).strftime("%d/%m/%Y"),
                                        key=f"valboleto_{prefix}")
        validade_cercon = st.text_input("Validade do Cercon (dd/mm/aaaa)",
                                        value=(data_convertida + timedelta(days=365)).strftime("%d/%m/%Y"),
                                        key=f"valcercon_{prefix}")
        prazo_vistoria = st.text_input("Vistoria até (dd/mm/aaaa)",
                                       value=(data_convertida + timedelta(days=30)).strftime("%d/%m/%Y"),
                                       key=f"vistoria_{prefix}")
        contato = st.text_input("Contato", value=dados["Contato"], key=f"cont_{prefix}")
        militar = st.selectbox("Militar Responsável",
                               ["Asp Of D'Lauan", "2° Sgt Tamilla", "2° Sgt Ribeiro", "2° Sgt Éderson"],
                               index=0, key=f"mil_{prefix}")
        andamento = st.selectbox("Andamento",
                                 ["Boleto Impresso", "Boleto Entregue", "Boleto Pago",
                                  "Isento", "MEI", "Processo Expirado", "Empresa Encerrou",
                                  "Cercon Impresso", "Empresa Não Encontrada"],
                                 index=0, key=f"and_{prefix}")

    return {
        "Data de Protocolo": data_raw,
        "Nº de Protocolo": protocolo,
        "Tipo de Serviço": tipo,
        "CPF/CNPJ": cpf,
        "Nome Fantasia": nome,
        "Área (m²)": area,
        "Valor Total": valor,
        "Validade do Boleto": validade_boleto,
        "Validade do Cercon": validade_cercon,
        "Prazo de Vistoria": prazo_vistoria,
        "Contato": contato,
        "Militar Responsável": militar,
        "Andamento": andamento
    }


# ───────────────────────────────────────────────────────────────────────────────
# INTERFACE PRINCIPAL
# ───────────────────────────────────────────────────────────────────────────────
def app():
    if st.session_state.get("forcar_reload"):
        st.session_state.pop("forcar_reload")
        st.rerun()

    st.title("📂 Gerenciamento de Protocolos - PORANGATU")

    df = carregar_dados()

    # 🔄 Mescla registros recém-inseridos que ainda não apareceram no backend
    buf = st.session_state.get("__buffer_inseridos__", [])
    if buf:
        ids_exist = set(df["ID"].astype(str)) if not df.empty else set()
        pendentes = [r for r in buf if str(r["ID"]) not in ids_exist]
        if pendentes:
            df = pd.concat([df, pd.DataFrame(pendentes)], ignore_index=True)
        # limpa do buffer os que já chegaram do backend
        st.session_state["__buffer_inseridos__"] = pendentes


    proximos_vencer, vencidos = classificar_vencimentos(df)

    # ───────────────────────────────────────────────────────────────
    # 1️⃣ CADASTRAR NOVO PROTOCOLO
    # ───────────────────────────────────────────────────────────────
    with st.expander("➕ Cadastrar Novo Protocolo", expanded=False):
        dados_novos = formulario_protocolo(prefix="novo")

        if st.button("💾 Salvar Novo Protocolo", key="salva_protocolo"):
            try:
                data_protocolo = datetime.strptime(dados_novos["Data de Protocolo"], "%d/%m/%Y").date()
                validade_boleto = datetime.strptime(dados_novos["Validade do Boleto"], "%d/%m/%Y").date()
                validade_cercon = datetime.strptime(dados_novos["Validade do Cercon"], "%d/%m/%Y").date()
                prazo_vistoria = datetime.strptime(dados_novos["Prazo de Vistoria"], "%d/%m/%Y").date()
            except ValueError:
                st.error("❌ Uma das datas está em formato inválido. Use dd/mm/aaaa.")
                st.stop()

            novo = {
                "ID": cria_id(),
                "Data de Protocolo": data_protocolo.strftime("%d/%m/%Y"),
                "Nº de Protocolo": dados_novos["Nº de Protocolo"],
                "Tipo de Serviço": dados_novos["Tipo de Serviço"],
                "CPF/CNPJ": dados_novos["CPF/CNPJ"],
                "Nome Fantasia": dados_novos["Nome Fantasia"],
                "Área (m²)": dados_novos["Área (m²)"],
                "Valor Total": dados_novos["Valor Total"],
                "Validade do Boleto": validade_boleto.strftime("%d/%m/%Y"),
                "Validade do Cercon": validade_cercon.strftime("%d/%m/%Y"),
                "Prazo de Vistoria": prazo_vistoria.strftime("%d/%m/%Y"),
                "Contato": dados_novos["Contato"],
                "Militar Responsável": dados_novos["Militar Responsável"],
                "Andamento": dados_novos["Andamento"]
            }

            insert(TABELA, novo)
            st.session_state.setdefault("__buffer_inseridos__", []).append(novo)

            st.success("✅ Protocolo salvo e já considerado nas listas!")
            st.rerun()
        # fim do with st.expander("➕ Cadastrar Novo Protocolo", ...)
    # ───────────────────────────────────────────────────────────────
    # 2️⃣ PROTOCOLOS EXISTENTES
    # ───────────────────────────────────────────────────────────────
    st.divider()
    st.subheader(f"📋 Protocolos Encontrados: {len(df)}")

    if df.empty:
        st.info("Nenhum protocolo encontrado.")
        return

    # lista de protocolos (com edição/exclusão)
    for _, row in df.iterrows():
        uid = row["ID"]
        titulo = f"🧾 {row.get('Nº de Protocolo','')} - {row.get('Nome Fantasia','')}"
        with st.expander(titulo):
            dados = formulario_protocolo(row, prefix=str(uid))

            col1, col2 = st.columns([3, 1], vertical_alignment="center")

            with col1:
                if st.button("💾 Atualizar", key=f"btn_{uid}"):
                    try:
                        # valida datas antes de salvar
                        datetime.strptime(dados["Data de Protocolo"], "%d/%m/%Y")
                        datetime.strptime(dados["Validade do Boleto"], "%d/%m/%Y")
                        datetime.strptime(dados["Validade do Cercon"], "%d/%m/%Y")
                        datetime.strptime(dados["Prazo de Vistoria"], "%d/%m/%Y")
                    except ValueError:
                        st.error("❌ Uma das datas está em formato inválido. Use dd/mm/aaaa.")
                        st.stop()

                    # força persistência de datas como texto dd/mm/aaaa
                    for campo in ["Data de Protocolo", "Validade do Boleto", "Validade do Cercon", "Prazo de Vistoria"]:
                        if campo in dados and dados[campo]:
                            try:
                                data_obj = datetime.strptime(dados[campo], "%d/%m/%Y")
                                dados[campo] = data_obj.strftime("%d/%m/%Y")
                            except Exception:
                                pass

                    campos = list(dados.keys())
                    valores = list(dados.values())
                    where = f"ID,=,{uid}"
                    update(TABELA, campos, valores, where, TIPOS_COLUNAS)

                    st.success("✅ Protocolo atualizado com sucesso!")
                    # se este registro estava no buffer (caso tenha sido criado agora),
                    # remove do buffer, pois já está 100% no backend
                    if "__buffer_inseridos__" in st.session_state:
                        st.session_state["__buffer_inseridos__"] = [
                            r for r in st.session_state["__buffer_inseridos__"] if str(r["ID"]) != str(uid)
                        ]
                    st.rerun()

            with col2:
                chave_confirma = f"confirmar_excluir_{uid}"
                if st.session_state.get(chave_confirma, False):
                    if st.button("❌ Confirmar Exclusão", key=f"confirma_{uid}"):
                        delete(TABELA, f"ID,=,{uid}", TIPOS_COLUNAS)
                        # também tira do buffer se existir
                        if "__buffer_inseridos__" in st.session_state:
                            st.session_state["__buffer_inseridos__"] = [
                                r for r in st.session_state["__buffer_inseridos__"] if str(r["ID"]) != str(uid)
                            ]
                        st.success("✅ Protocolo excluído com sucesso!")
                        st.rerun()
                    if st.button("↩️ Cancelar", key=f"cancela_{uid}"):
                        st.session_state[chave_confirma] = False
                else:
                    if st.button("🗑️ Excluir", key=f"del_{uid}"):
                        st.session_state[chave_confirma] = True

    # ───────────────────────────────────────────────────────────────
    # ⚠️ AVISOS DE VENCIMENTO
    # ───────────────────────────────────────────────────────────────
    if not proximos_vencer.empty:
        st.divider()
        st.markdown("### ⚠️ Cercons próximos ao vencimento (≤ 30 dias)")
        for _, r in proximos_vencer.iterrows():
            data_formatada = (
                r["Validade do Cercon_dt"].strftime("%d/%m/%Y")
                if pd.notna(r.get("Validade do Cercon_dt"))
                else r.get("Validade do Cercon", "—")
            )
            st.markdown(
                f"""
                <div style="background-color:#fff3cd;padding:10px;border-radius:6px;margin-bottom:6px">
                    <strong>{r.get('Nº de Protocolo','')} - {r.get('Nome Fantasia','')}</strong><br>
                    Vence em: {data_formatada}
                </div>
                """,
                unsafe_allow_html=True
            )

    if not vencidos.empty:
        st.divider()
        st.markdown("### ❌ Cercons vencidos")
        for _, r in vencidos.iterrows():
            data_formatada = (
                r["Validade do Cercon_dt"].strftime("%d/%m/%Y")
                if pd.notna(r.get("Validade do Cercon_dt"))
                else r.get("Validade do Cercon", "—")
            )
            st.markdown(
                f"""
                <div style="background-color:#f8d7da;padding:10px;border-radius:6px;margin-bottom:6px">
                    <strong>{r.get('Nº de Protocolo','')} - {r.get('Nome Fantasia','')}</strong><br>
                    Vencido em: {data_formatada}
                </div>
                """,
                unsafe_allow_html=True
            )
